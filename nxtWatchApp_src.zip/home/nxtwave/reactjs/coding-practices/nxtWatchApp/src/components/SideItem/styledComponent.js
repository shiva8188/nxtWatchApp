import styled from 'styled-components'

export const Li = styled.li`
  list-style-type: none;
  display: flex;
  flex-direction: column;
`
export const Div = styled.div`
  diplay: flex;
  align-items: center;
`
